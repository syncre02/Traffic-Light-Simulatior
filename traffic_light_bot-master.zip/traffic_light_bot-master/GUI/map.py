import time
import pygame

from pygame import Rect

BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
BLUE = (0, 0, 255)
GREEN = (0, 255, 0)
RED = (255, 0, 0)
DG = (34, 139, 34)
YELLOW = (255, 255, 0)


class Map:
    X_pos = 0
    Y_pos = 0
    m = None
    Light2 = None
    Light3 = None
    Light4 = None
    LightSetColo = GREEN
    Str1 = "G"
    LightSetColo2 = RED
    Str2 = "R"
    Xs = 0
    Ys = 0
    setRectX = []
    setRectY = []
    right_queue = []
    left_queue = []
    up_queue = []
    down_queue = []
    lightSwitchTimer = time.time()
    queueFilled = False
    screen = None
    def __init__(self, xpos, ypos, size_x, size_y,gui):
        self.X_pos = xpos
        self.Y_pos = ypos
        self.Xs = size_x
        self.Ys = size_y
        self.m = (self.X_pos + 5, self.X_pos + int(size_x / 2))
        self.Light2 = (self.X_pos + size_x - 5, self.X_pos + int(size_x / 2))
        self.Light3 = (self.X_pos + int(size_x / 2), self.X_pos + 5)
        self.Light4 = (self.X_pos + int(size_x / 2), self.X_pos + size_x - 5)

        object_1 = Rect(self.X_pos + size_x, self.X_pos, 5, 80)
        object_2 = Rect(self.X_pos - 5, self.X_pos, 5, 80)
        object_3 = Rect(self.X_pos, self.X_pos - 5, 80, 5)
        object_4 = Rect(self.X_pos, self.X_pos + size_x, 80, 5)
        self.setRectX.append(object_1)
        self.setRectX.append(object_2)
        self.setRectY.append(object_3)
        self.setRectY.append(object_4)
        self.screen = gui
    def draw_map(self):
        pygame.draw.rect(self.screen, BLACK, (self.X_pos, self.Y_pos, self.Xs, self.Ys))
        pygame.draw.rect(self.screen, BLACK, (self.Y_pos, self.X_pos, self.Ys, self.Xs))  # Roads
        pygame.draw.rect(self.screen, WHITE, self.setRectX[0])  # Markers
        pygame.draw.rect(self.screen, WHITE, self.setRectX[1])
        pygame.draw.rect(self.screen, WHITE, self.setRectY[0])
        pygame.draw.rect(self.screen, WHITE, self.setRectY[1])
        pygame.draw.circle(self.screen, self.LightSetColo, self.m, 5)  # Light
        pygame.draw.circle(self.screen, self.LightSetColo, self.Light2, 5)
        pygame.draw.circle(self.screen, self.LightSetColo2, self.Light3, 5)
        pygame.draw.circle(self.screen, self.LightSetColo2, self.Light4, 5)

    def changeColor(self, side):
        self.lightSwitchTimer = time.time()
        if side == 0:
            if self.LightSetColo == YELLOW or self.LightSetColo == GREEN:
                self.LightSetColo2 = RED
                self.Str2 = "R"
                if self.LightSetColo == YELLOW:
                    self.LightSetColo = RED
                    self.Str1 = "R"
                    self.LightSetColo2 = GREEN
                    self.Str2 = "G"
                elif self.LightSetColo == GREEN:
                    self.LightSetColo = YELLOW
                    self.Str1 = "Y"
            elif self.LightSetColo2 == YELLOW or self.LightSetColo2 == GREEN:
                self.LightSetColo = RED
                self.Str1 = "R"
                if self.LightSetColo2 == YELLOW:
                    self.LightSetColo2 = RED
                    self.Str2 = "R"
                    self.LightSetColo = GREEN
                    self.Str1 = "G"
                elif self.LightSetColo2 == GREEN:
                    self.LightSetColo2 = YELLOW
                    self.Str2 = "Y"
        elif not self.queueFilled:
            if side == 1:
                self.LightSetColo = RED
                self.Str1 = "R"
                self.LightSetColo2 = YELLOW
                self.Str2 = "Y"
            elif side == 2:
                self.LightSetColo2 = RED
                self.Str2 = "R"
                self.LightSetColo = YELLOW
                self.Str1 = "Y"
            self.queueFilled = True
            self.lightSwitchTimer = time.time()

    def getYellow(self):
        if self.Str1 == "Y" or self.Str2 == "Y":
            return int(3)
        else:
            return int(7)

    def markersInX(self):
        return self.setRectX

    def markersInY(self):
        return self.setRectY

    def HorzLightColor(self):
        return self.Str1

    def VertLightColor(self):
        return self.Str2

    def CarQueue(self, side):
        if side == "left":
            return len(self.left_queue)
        if side == "right":
            return len(self.right_queue)
        if side == "up":
            return len(self.up_queue)
        if side == "down":
            return len(self.down_queue)

    def addCar(self, side):
        if side == "left":
            self.left_queue.append("1")
        if side == "right":
            self.right_queue.append("1")
        if side == "up":
            self.up_queue.append("1")
        if side == "down":
            self.down_queue.append("1")

    def delCar(self, side):
        if side == "left" and len(self.left_queue) != 0:
            self.left_queue.pop(0)
        if side == "right" and len(self.right_queue) != 0:
            self.right_queue.pop(0)
        if side == "up" and len(self.up_queue) != 0:
            self.up_queue.pop(0)
        if side == "down" and len(self.down_queue) != 0:
            self.down_queue.pop(0)

    def getQueue(self, side):
        if side == "left":
            return self.left_queue
        if side == "right":
            return self.right_queue
        if side == "up":
            return self.up_queue
        if side == "down":
            return self.down_queue

    def carsOnHorz(self):
        return len(self.left_queue) + len(self.right_queue)

    def carsOnVert(self):
        return len(self.down_queue) + len(self.up_queue)