import pygame
import random
import sys
import time

from map import Map
from car import Car

BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
BLUE = (0, 0, 255)
GREEN = (0, 255, 0)
RED = (255, 0, 0)
DG = (34, 139, 34)
YELLOW = (255, 255, 0)

pygame.init()

size = width, height = 600, 600
screen = pygame.display.set_mode(size)

car_list = []

MapX = 250
MapY = 0
MapList = []
map1 = Map(MapX, MapY, 80, 600,screen)
MapList.append(map1)

prevTime = time.time()
while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.display.quit()
            pygame.quit()
            sys.exit(0)
    screen.fill(DG)

    if (time.time() - prevTime) > (int(random.random() * 8) + 2):
        randInt = int(random.random() * 5)
        if randInt == 0:
            car_list.append(Car(MapX + 15, MapY, "vertical", "up"))
        if randInt == 1:
            car_list.append(Car(MapY, MapX + 45, "horizontal", "left"))
        if randInt == 2:
            car_list.append(Car(MapX + 45, 600 - MapY, "vertical", "down"))
        if randInt == 3:
            car_list.append(Car(600 - MapY, MapX + 15, "horizontal", "right"))
        prevTime = time.time()

    for i in car_list:
        pygame.draw.rect(screen, GREEN, i.get_rect(), 0)

    for m in MapList:
        m.draw_map()
        if m.carsOnHorz() >= 3 and m.carsOnVert() == 0:
            if m.queueFilled:
                m.changeColor(0)
            else:
                m.changeColor(1)
        elif m.carsOnVert() >= 3 and m.carsOnHorz() == 0:
            if m.queueFilled:
                m.changeColor(0)
            else:
                m.changeColor(2)
        elif abs(m.lightSwitchTimer - time.time()) > m.getYellow():
            m.changeColor(0)

        for i in car_list:
            pygame.draw.rect(screen, RED, i.getCar())

            if i.get_rect().collidelist(m.markersInX()) != -1 or i.get_rect().collidelist(m.markersInY()) != -1:
                if not i.getRightPass():
                    rand = random.randint(0, 4)
                    i.setRight(rand)
                    i.setRightPass()

            if i.randomized_right != 0:
                if i.getPass():
                    i.move(True)
                else:
                    if i.get_direct() == "vertical":
                        if m.VertLightColor() == "G" or m.VertLightColor() == "Y":
                            i.move(True)
                            if ((i.get_rect().collidelist(m.markersInX()) != -1 or i.get_rect().collidelist(m.markersInY()) != -1)):
                                i.SetPass()
                            i.movements = False
                        else:
                            if (i.get_rect().collidelist(m.markersInX()) == -1 and i.get_rect().collidelist(
                                    m.markersInY()) == -1):
                                for x in car_list:
                                    if i != x and i.get_rect().colliderect(x.get_rect()):
                                        i.move(False)
                                    else:
                                        i.move(True)
                            else:
                                i.move(False)
                    else:
                        if i.get_direct() == "horizontal":
                            if m.HorzLightColor() == "G" or m.HorzLightColor() == "Y":
                                i.move(True)
                                if ((i.get_rect().collidelist(m.markersInX()) != -1 or i.get_rect().collidelist(m.markersInY()) != -1)):
                                    i.SetPass()
                                i.movements = False
                            else:
                                if ((i.get_rect().collidelist(m.markersInX()) == -1 and i.get_rect().collidelist(m.markersInY()) == -1)):
                                    for x in car_list:
                                        if i != x and i.get_rect().colliderect(x.get_rect()):
                                            i.move(False)
                                        else:
                                            i.move(True)
                                else:
                                    i.move(False)
            else:
                if i.get_direct() == "vertical":
                    if m.VertLightColor() == "G" or m.VertLightColor() == "Y":
                        i.moveRight()
                elif i.get_direct() == "horizontal":
                    if m.HorzLightColor() == "G" or m.HorzLightColor() == "Y":
                        i.moveRight()
            if i.get_move() and not i.getInLine():
                m.addCar(i.get_true_dir())
                i.setInLine()
            if not i.get_move() and i.getInLine():
                m.delCar(i.get_true_dir())
                i.setInLine()
            XPos, YPos = i.getLoc()
            if XPos > 600 or XPos < 0 or YPos > 600 or YPos < 0:
                car_list.remove(i)

    pygame.display.flip()
    pygame.display.update()
    time.sleep(0.005)
