import time

from pygame import Rect


class Car:
    rectangle = None
    X_pos = 0
    Y_pos = 0
    direct = ""
    speed = 0
    movements = False
    trueDirect = 0
    Car = 0
    LinePasses = False
    timeDriving = 0
    WaitingInLine = False
    randomized_right = 9999
    rightTurnLinePass = False
    def __init__(self, xpos, ypos, direction, true_dir):
        self.speed = 1
        self.rectangle = Rect(xpos - 5, ypos - 5, 30, 30)
        self.Car = Rect(xpos, ypos, 20, 20)
        self.X_pos = xpos
        self.Y_pos = ypos
        self.direct = direction
        self.trueDirect = true_dir
        self.timeDriving = time.time()
    def get_rect(self):
        return self.rectangle

    def get_direct(self):
        return self.direct

    def get_time_driving(self):
        return self.timeDriving

    def move(self, loc):
        if loc and not self.get_move():
            if self.trueDirect == "up":
                self.rectangle = self.rectangle.move(0, self.speed)
                self.Car = self.Car.move(0, self.speed)
                self.Y_pos += self.speed
            if self.trueDirect == "down":
                self.rectangle = self.rectangle.move(0, self.speed * -1)
                self.Car = self.Car.move(0, self.speed * -1)
                self.Y_pos += self.speed * -1
            if self.trueDirect == "right":
                self.rectangle = self.rectangle.move(self.speed * -1, 0)
                self.Car = self.Car.move(self.speed * -1, 0)
                self.X_pos += self.speed * -1
            if self.trueDirect == "left":
                self.rectangle = self.rectangle.move(self.speed, 0)
                self.Car = self.Car.move(self.speed, 0)
                self.X_pos += self.speed
        elif not loc and not self.get_move():
            if self.trueDirect == "up":
                self.rectangle = self.rectangle.move(0, self.speed * -1)
                self.Car = self.Car.move(0, self.speed * -1)
                self.Y_pos += self.speed * 1
            if self.trueDirect == "down":
                self.rectangle = self.rectangle.move(0, self.speed)
                self.Car = self.Car.move(0, self.speed)
                self.Y_pos += self.speed
            if self.trueDirect == "right":
                self.rectangle = self.rectangle.move(self.speed, 0)
                self.Car = self.Car.move(self.speed, 0)
                self.X_pos += self.speed
            if self.trueDirect == "left":
                self.rectangle = self.rectangle.move(self.speed * -1, 0)
                self.Car = self.Car.move(self.speed * -1, 0)
                self.X_pos += self.speed * -1
            self.movements = True

    def get_move(self):
        return self.movements

    def get_true_dir(self):
        return self.trueDirect

    def getCar(self):
        return self.Car

    def getLoc(self):
        return self.X_pos, self.Y_pos

    def setInLine(self):
        self.WaitingInLine = not self.WaitingInLine

    def getInLine(self):
        return self.WaitingInLine

    def SetPass(self):
        self.LinePasses = not self.LinePasses


    def getPass(self):
        return self.LinePasses

    def setRightPass(self):
        self.rightTurnLinePass = True

    def getRightPass(self):
        return self.rightTurnLinePass

    def setRight(self, val):
        if not self.getRightPass():
            self.randomized_right = val

    def moveRight(self):
        multi = int(40)
        sleep_time = 0
        if self.trueDirect == "up":
            for j in range(multi):
                self.rectangle = self.rectangle.move(0, self.speed)
                self.Car = self.Car.move(0, self.speed)
                time.sleep(sleep_time)
            self.trueDirect = "right"
            self.direct = "horizontal"
        elif self.trueDirect == "down":
            for j in range(multi):
                self.rectangle = self.rectangle.move(0, self.speed * -1)
                self.Car = self.Car.move(0, self.speed * -1)
                time.sleep(sleep_time)
            self.trueDirect = "left"
            self.direct = "horizontal"
        elif self.trueDirect == "right":
            for j in range(multi):
                self.rectangle = self.rectangle.move(self.speed * -1, 0)
                self.Car = self.Car.move(self.speed * -1, 0)
                time.sleep(sleep_time)
            self.trueDirect = "down"
            self.direct = "vertical"
        elif self.trueDirect == "left":
            for j in range(multi):
                self.rectangle = self.rectangle.move(self.speed, 0)
                self.Car = self.Car.move(self.speed, 0)
                time.sleep(sleep_time)
            self.trueDirect = "up"
            self.direct = "vertical"
        for j in range(45):
            self.move(True)
            time.sleep(sleep_time)
        self.randomized_right = 99999
        self.rightTurnLinePass = False
