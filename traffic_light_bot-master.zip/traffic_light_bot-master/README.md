# traffic_light_bot
Keras model intended to find optimal ways to operate traffic lights
